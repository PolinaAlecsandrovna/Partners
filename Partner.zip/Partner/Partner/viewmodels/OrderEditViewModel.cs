﻿using PartnerOrderApp.WPF.Models;      
using PartnerOrderApp.WPF.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;

namespace PartnerOrderApp.WPF.ViewModels
{
    public class OrderEditViewModel : ViewModelBase
    {
        private readonly DatabaseService _dbService;
        private readonly OrderService _orderService;
        private readonly DialogService _dialogService;

        private PartnerOrder _currentOrder;
        private List<Models.Partner> _partners = new();
        private List<Product> _products = new();
        private List<OrderStatus> _statuses = new();
        private bool _isEditMode;
        private bool _isLoading;
        private string _title = string.Empty;

        public PartnerOrder CurrentOrder => _currentOrder;

        public List<Models.Partner> Partners
        {
            get => _partners;
            set { _partners = value; OnPropertyChanged(); }
        }

        public List<Product> Products
        {
            get => _products;
            set { _products = value; OnPropertyChanged(); }
        }

        public List<OrderStatus> Statuses
        {
            get => _statuses;
            set { _statuses = value; OnPropertyChanged(); }
        }

        public bool IsEditMode
        {
            get => _isEditMode;
            set { _isEditMode = value; OnPropertyChanged(); }
        }

        public bool IsLoading
        {
            get => _isLoading;
            set { _isLoading = value; OnPropertyChanged(); }
        }

        public string Title
        {
            get => _title;
            set { _title = value; OnPropertyChanged(); }
        }

        public decimal TotalCost => _orderService.CalculateTotalCost(_currentOrder.Items);

        public ICommand AddProductCommand { get; }
        public ICommand RemoveProductCommand { get; }
        public ICommand SaveCommand { get; }
        public ICommand CancelCommand { get; }

        public event EventHandler SaveCompleted;
        public event EventHandler CancelRequested;

        public OrderEditViewModel(DatabaseService dbService, OrderService orderService,
            DialogService dialogService, PartnerOrder order = null)
        {
            _dbService = dbService;
            _orderService = orderService;
            _dialogService = dialogService;

            _currentOrder = order ?? new PartnerOrder
            {
                Items = new ObservableCollection<OrderItem>(),
                OrderDate = DateTime.Now,
                PrepaymentDeadline = DateTime.Now.AddDays(3)
            };

            IsEditMode = order != null;
            Title = IsEditMode ? "Редактирование заявки" : "Новая заявка";

            AddProductCommand = new RelayCommand(OnAddProduct, _ => !IsLoading);
            RemoveProductCommand = new RelayCommand(OnRemoveProduct, _ => !IsLoading);
            SaveCommand = new RelayCommand(async _ => await OnSave(), _ => !IsLoading);
            CancelCommand = new RelayCommand(_ => CancelRequested?.Invoke(this, EventArgs.Empty));

            LoadDataAsync();
        }

        private async void LoadDataAsync()
        {
            IsLoading = true;
            try
            {
                Partners = await _dbService.GetAllPartnersAsync();
                Products = await _dbService.GetAllProductsAsync();
                Statuses = await _dbService.GetOrderStatusesAsync();

                if (Partners.Any())
                    _currentOrder.PartnerId = Partners.First().Id;

                if (Statuses.Any())
                    _currentOrder.OrderStatusId = Statuses.First().Id;

                OnPropertyChanged(nameof(CurrentOrder));
            }
            catch (Exception ex)
            {
                _dialogService.ShowError($"Ошибка загрузки данных: {ex.Message}");
            }
            finally
            {
                IsLoading = false;
            }
        }

        private void OnAddProduct(object parameter)
        {
            if (!(parameter is Product product) || product.Id <= 0)
            {
                _dialogService.ShowWarning("Выберите продукт из списка");
                return;
            }

            if (_currentOrder.Items.Any(i => i.ProductId == product.Id))
            {
                _dialogService.ShowWarning("Этот продукт уже добавлен в заявку");
                return;
            }

            var item = new OrderItem
            {
                ProductId = product.Id,
                ProductName = product.Name,
                Quantity = 1,
                UnitPrice = product.MinPartnerPrice
            };

            _currentOrder.Items.Add(item);
            OnPropertyChanged(nameof(TotalCost));
            OnPropertyChanged(nameof(CurrentOrder));
        }



        private void OnRemoveProduct(object parameter)
        {
            if (!(parameter is OrderItem item))
            {
                _dialogService.ShowWarning("Выберите продукт для удаления");
                return;
            }

            _currentOrder.Items.Remove(item); 
            OnPropertyChanged(nameof(TotalCost));
            OnPropertyChanged(nameof(CurrentOrder));
        }

        private async Task OnSave()
        {
            if (!_orderService.IsOrderValid(_currentOrder, out string errorMessage))
            {
                _dialogService.ShowWarning(errorMessage);
                return;
            }

            try
            {
                IsLoading = true;

                if (IsEditMode)
                {
                    await _dbService.UpdateOrderAsync(_currentOrder);
                    _dialogService.ShowMessage("Заявка успешно обновлена", "Успех");
                }
                else
                {
                    await _dbService.AddOrderAsync(_currentOrder);
                    _dialogService.ShowMessage("Заявка успешно создана", "Успех");
                }

                SaveCompleted?.Invoke(this, EventArgs.Empty);
            }
            catch (Exception ex)
            {
                _dialogService.ShowError($"Ошибка сохранения: {ex.Message}");
            }
            finally
            {
                IsLoading = false;
            }
        }

        public void SetOrder(PartnerOrder order)
        {
            _currentOrder = order;
            OnPropertyChanged(nameof(CurrentOrder));
            OnPropertyChanged(nameof(TotalCost));
        }
    }
}
