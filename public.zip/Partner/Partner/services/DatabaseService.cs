﻿using Npgsql;
using PartnerOrderApp.WPF.Helpers;
using PartnerOrderApp.WPF.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading.Tasks;

namespace PartnerOrderApp.WPF.Services
{
    public class DatabaseService
    {
        private readonly DatabaseHelper _dbHelper;

        public DatabaseService(string connectionString)
        {
            _dbHelper = new DatabaseHelper(connectionString);
        }

        public async Task<bool> TestConnectionAsync()
        {
            return await _dbHelper.TestConnectionAsync();
        }

        public async Task<List<PartnerOrder>> GetAllOrdersAsync()
        {
            var orders = new List<PartnerOrder>();
            var query = @"
                SELECT 
                    po.id AS order_id,
                    po.partner_id,
                    po.order_status_id,
                    po.order_date,
                    po.prepayment_deadline,
                    po.prepayment_received,
                    po.total_cost,
                    po.comment,
                    p.company_name,
                    pt.name AS partner_type_name,
                    p.phone,
                    p.rating,
                    os.name AS order_status_name
                FROM partner_orders po
                JOIN partners p ON po.partner_id = p.id
                JOIN partner_types pt ON p.partner_type_id = pt.id
                JOIN order_statuses os ON po.order_status_id = os.id
                ORDER BY po.id DESC";

            using (var conn = _dbHelper.GetConnection())
            {
                await conn.OpenAsync();
                using (var cmd = new NpgsqlCommand(query, conn))
                {
                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            var order = new PartnerOrder
                            {
                                Id = reader.GetInt32(reader.GetOrdinal("order_id")),
                                PartnerId = reader.GetInt32(reader.GetOrdinal("partner_id")),
                                PartnerName = reader.GetString(reader.GetOrdinal("company_name")),
                                PartnerTypeName = reader.GetString(reader.GetOrdinal("partner_type_name")),
                                PartnerPhone = reader.GetString(reader.GetOrdinal("phone")),
                                PartnerRating = reader.GetInt32(reader.GetOrdinal("rating")),
                                OrderStatusId = reader.GetInt32(reader.GetOrdinal("order_status_id")),
                                OrderStatusName = reader.GetString(reader.GetOrdinal("order_status_name")),
                                OrderDate = reader.GetDateTime(reader.GetOrdinal("order_date")),
                                TotalCost = reader.GetDecimal(reader.GetOrdinal("total_cost")),
                                Comment = reader.IsDBNull(reader.GetOrdinal("comment"))
                                    ? null
                                    : reader.GetString(reader.GetOrdinal("comment"))
                            };

                            if (!reader.IsDBNull(reader.GetOrdinal("prepayment_deadline")))
                            {
                                order.PrepaymentDeadline = reader.GetDateTime(reader.GetOrdinal("prepayment_deadline"));
                            }
                            order.PrepaymentReceived = reader.GetBoolean(reader.GetOrdinal("prepayment_received"));

                            orders.Add(order);
                        }
                    }
                }
            }

            // Загружаем позиции для каждой заявки
            foreach (var order in orders)
            {
                order.Items = new ObservableCollection<OrderItem>(
                    await GetOrderItemsAsync(order.Id)
                );
            }

            return orders;
        }

        public async Task<List<OrderItem>> GetOrderItemsAsync(int orderId)
        {
            var items = new List<OrderItem>();
            var query = @"
                SELECT 
                    oi.id,
                    oi.order_id,
                    oi.product_id,
                    oi.quantity,
                    oi.unit_price,
                    p.name AS product_name
                FROM order_items oi
                JOIN products p ON oi.product_id = p.id
                WHERE oi.order_id = @orderId";

            using (var conn = _dbHelper.GetConnection())
            {
                await conn.OpenAsync();
                using (var cmd = new NpgsqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@orderId", orderId);
                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            items.Add(new OrderItem
                            {
                                Id = reader.GetInt32(reader.GetOrdinal("id")),
                                OrderId = reader.GetInt32(reader.GetOrdinal("order_id")),
                                ProductId = reader.GetInt32(reader.GetOrdinal("product_id")),
                                ProductName = reader.GetString(reader.GetOrdinal("product_name")),
                                Quantity = reader.GetInt32(reader.GetOrdinal("quantity")),
                                UnitPrice = reader.GetDecimal(reader.GetOrdinal("unit_price"))
                            });
                        }
                    }
                }
            }

            return items;
        }

        public async Task<List<Partner>> GetAllPartnersAsync()
        {
            var partners = new List<Partner>();
            var query = @"
                SELECT 
                    p.id,
                    p.partner_type_id,
                    pt.name AS partner_type_name,
                    p.company_name,
                    p.inn,
                    p.director_surname,
                    p.director_name,
                    p.director_patronymic,
                    p.phone,
                    p.email,
                    p.rating,
                    CONCAT(c.name, ', ', s.name, ', ', p.building) AS address
                FROM partners p
                JOIN partner_types pt ON p.partner_type_id = pt.id
                JOIN cities c ON p.city_id = c.id
                JOIN streets s ON p.street_id = s.id
                ORDER BY p.company_name";

            using (var conn = _dbHelper.GetConnection())
            {
                await conn.OpenAsync();
                using (var cmd = new NpgsqlCommand(query, conn))
                {
                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            partners.Add(new Partner
                            {
                                Id = reader.GetInt32(reader.GetOrdinal("id")),
                                PartnerTypeId = reader.GetInt32(reader.GetOrdinal("partner_type_id")),
                                PartnerTypeName = reader.GetString(reader.GetOrdinal("partner_type_name")),
                                CompanyName = reader.GetString(reader.GetOrdinal("company_name")),
                                Inn = reader.GetString(reader.GetOrdinal("inn")),
                                DirectorSurname = reader.GetString(reader.GetOrdinal("director_surname")),
                                DirectorName = reader.GetString(reader.GetOrdinal("director_name")),
                                DirectorPatronymic = reader.IsDBNull(reader.GetOrdinal("director_patronymic"))
                                    ? string.Empty
                                    : reader.GetString(reader.GetOrdinal("director_patronymic")),
                                Phone = reader.GetString(reader.GetOrdinal("phone")),
                                Email = reader.IsDBNull(reader.GetOrdinal("email"))
                                    ? string.Empty
                                    : reader.GetString(reader.GetOrdinal("email")),
                                Rating = reader.GetInt32(reader.GetOrdinal("rating")),
                                Address = reader.GetString(reader.GetOrdinal("address"))
                            });
                        }
                    }
                }
            }

            return partners;
        }

        public async Task<List<Product>> GetAllProductsAsync()
        {
            var products = new List<Product>();
            var query = "SELECT id, article, name, min_partner_price FROM products ORDER BY name";

            using (var conn = _dbHelper.GetConnection())
            {
                await conn.OpenAsync();
                using (var cmd = new NpgsqlCommand(query, conn))
                {
                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            products.Add(new Product
                            {
                                Id = reader.GetInt32(reader.GetOrdinal("id")),
                                Article = reader.GetString(reader.GetOrdinal("article")),
                                Name = reader.GetString(reader.GetOrdinal("name")),
                                MinPartnerPrice = reader.GetDecimal(reader.GetOrdinal("min_partner_price"))
                            });
                        }
                    }
                }
            }

            return products;
        }

        public async Task<List<OrderStatus>> GetOrderStatusesAsync()
        {
            var statuses = new List<OrderStatus>();
            var query = "SELECT id, name FROM order_statuses ORDER BY id";

            using (var conn = _dbHelper.GetConnection())
            {
                await conn.OpenAsync();
                using (var cmd = new NpgsqlCommand(query, conn))
                {
                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            statuses.Add(new OrderStatus
                            {
                                Id = reader.GetInt32(reader.GetOrdinal("id")),
                                Name = reader.GetString(reader.GetOrdinal("name"))
                            });
                        }
                    }
                }
            }

            return statuses;
        }

        public async Task<int> AddOrderAsync(PartnerOrder order)
        {
            using (var conn = _dbHelper.GetConnection())
            {
                await conn.OpenAsync();

                using (var transaction = await conn.BeginTransactionAsync())
                {
                    try
                    {
                        var query = @"
                            INSERT INTO partner_orders 
                                (partner_id, order_status_id, order_date, prepayment_deadline, 
                                 prepayment_received, total_cost, comment)
                            VALUES 
                                (@partnerId, @orderStatusId, @orderDate, @prepaymentDeadline,
                                 @prepaymentReceived, @totalCost, @comment)
                            RETURNING id";

                        using (var cmd = new NpgsqlCommand(query, conn, transaction))
                        {
                            cmd.Parameters.AddWithValue("@partnerId", order.PartnerId);
                            cmd.Parameters.AddWithValue("@orderStatusId", order.OrderStatusId);
                            cmd.Parameters.AddWithValue("@orderDate", order.OrderDate);
                            cmd.Parameters.AddWithValue("@prepaymentDeadline",
                                order.PrepaymentDeadline.HasValue ? (object)order.PrepaymentDeadline.Value : DBNull.Value);
                            cmd.Parameters.AddWithValue("@prepaymentReceived", order.PrepaymentReceived);
                            cmd.Parameters.AddWithValue("@totalCost", order.TotalCost);
                            cmd.Parameters.AddWithValue("@comment",
                                string.IsNullOrEmpty(order.Comment) ? DBNull.Value : (object)order.Comment);

                            var orderId = Convert.ToInt32(await cmd.ExecuteScalarAsync());

                            if (order.Items != null && order.Items.Count > 0)
                            {
                                foreach (var item in order.Items)
                                {
                                    var itemQuery = @"
                                        INSERT INTO order_items 
                                            (order_id, product_id, quantity, unit_price)
                                        VALUES 
                                            (@orderId, @productId, @quantity, @unitPrice)";

                                    using (var itemCmd = new NpgsqlCommand(itemQuery, conn, transaction))
                                    {
                                        itemCmd.Parameters.AddWithValue("@orderId", orderId);
                                        itemCmd.Parameters.AddWithValue("@productId", item.ProductId);
                                        itemCmd.Parameters.AddWithValue("@quantity", item.Quantity);
                                        itemCmd.Parameters.AddWithValue("@unitPrice", item.UnitPrice);
                                        await itemCmd.ExecuteNonQueryAsync();
                                    }
                                }
                            }

                            await transaction.CommitAsync();
                            return orderId;
                        }
                    }
                    catch
                    {
                        await transaction.RollbackAsync();
                        throw;
                    }
                }
            }
        }

        public async Task UpdateOrderAsync(PartnerOrder order)
        {
            using (var conn = _dbHelper.GetConnection())
            {
                await conn.OpenAsync();

                using (var transaction = await conn.BeginTransactionAsync())
                {
                    try
                    {
                        var query = @"
                            UPDATE partner_orders 
                            SET 
                                partner_id = @partnerId,
                                order_status_id = @orderStatusId,
                                order_date = @orderDate,
                                prepayment_deadline = @prepaymentDeadline,
                                prepayment_received = @prepaymentReceived,
                                total_cost = @totalCost,
                                comment = @comment,
                                updated_at = CURRENT_TIMESTAMP
                            WHERE id = @orderId";

                        using (var cmd = new NpgsqlCommand(query, conn, transaction))
                        {
                            cmd.Parameters.AddWithValue("@orderId", order.Id);
                            cmd.Parameters.AddWithValue("@partnerId", order.PartnerId);
                            cmd.Parameters.AddWithValue("@orderStatusId", order.OrderStatusId);
                            cmd.Parameters.AddWithValue("@orderDate", order.OrderDate);
                            cmd.Parameters.AddWithValue("@prepaymentDeadline",
                                order.PrepaymentDeadline.HasValue ? (object)order.PrepaymentDeadline.Value : DBNull.Value);
                            cmd.Parameters.AddWithValue("@prepaymentReceived", order.PrepaymentReceived);
                            cmd.Parameters.AddWithValue("@totalCost", order.TotalCost);
                            cmd.Parameters.AddWithValue("@comment",
                                string.IsNullOrEmpty(order.Comment) ? DBNull.Value : (object)order.Comment);
                            await cmd.ExecuteNonQueryAsync();
                        }

                        var deleteQuery = "DELETE FROM order_items WHERE order_id = @orderId";
                        using (var deleteCmd = new NpgsqlCommand(deleteQuery, conn, transaction))
                        {
                            deleteCmd.Parameters.AddWithValue("@orderId", order.Id);
                            await deleteCmd.ExecuteNonQueryAsync();
                        }

                        if (order.Items != null && order.Items.Count > 0)
                        {
                            foreach (var item in order.Items)
                            {
                                var itemQuery = @"
                                    INSERT INTO order_items 
                                        (order_id, product_id, quantity, unit_price)
                                    VALUES 
                                        (@orderId, @productId, @quantity, @unitPrice)";

                                using (var itemCmd = new NpgsqlCommand(itemQuery, conn, transaction))
                                {
                                    itemCmd.Parameters.AddWithValue("@orderId", order.Id);
                                    itemCmd.Parameters.AddWithValue("@productId", item.ProductId);
                                    itemCmd.Parameters.AddWithValue("@quantity", item.Quantity);
                                    itemCmd.Parameters.AddWithValue("@unitPrice", item.UnitPrice);
                                    await itemCmd.ExecuteNonQueryAsync();
                                }
                            }
                        }

                        await transaction.CommitAsync();
                    }
                    catch
                    {
                        await transaction.RollbackAsync();
                        throw;
                    }
                }
            }
        }

        public async Task DeleteOrderAsync(int orderId)
        {
            var query = "DELETE FROM partner_orders WHERE id = @orderId";
            using (var conn = _dbHelper.GetConnection())
            {
                await conn.OpenAsync();
                using (var cmd = new NpgsqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@orderId", orderId);
                    await cmd.ExecuteNonQueryAsync();
                }
            }
        }

        public async Task<PartnerOrder> GetOrderByIdAsync(int orderId)
        {
            var query = @"
                SELECT 
                    po.id AS order_id,
                    po.partner_id,
                    po.order_status_id,
                    po.order_date,
                    po.prepayment_deadline,
                    po.prepayment_received,
                    po.total_cost,
                    po.comment,
                    p.company_name,
                    pt.name AS partner_type_name,
                    p.phone,
                    p.rating,
                    os.name AS order_status_name,
                    CONCAT(c.name, ', ', s.name, ', ', p.building) AS address
                FROM partner_orders po
                JOIN partners p ON po.partner_id = p.id
                JOIN partner_types pt ON p.partner_type_id = pt.id
                JOIN order_statuses os ON po.order_status_id = os.id
                JOIN cities c ON p.city_id = c.id
                JOIN streets s ON p.street_id = s.id
                WHERE po.id = @orderId";

            using (var conn = _dbHelper.GetConnection())
            {
                await conn.OpenAsync();
                using (var cmd = new NpgsqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@orderId", orderId);
                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        if (await reader.ReadAsync())
                        {
                            var order = new PartnerOrder
                            {
                                Id = reader.GetInt32(reader.GetOrdinal("order_id")),
                                PartnerId = reader.GetInt32(reader.GetOrdinal("partner_id")),
                                PartnerName = reader.GetString(reader.GetOrdinal("company_name")),
                                PartnerTypeName = reader.GetString(reader.GetOrdinal("partner_type_name")),
                                PartnerPhone = reader.GetString(reader.GetOrdinal("phone")),
                                PartnerRating = reader.GetInt32(reader.GetOrdinal("rating")),
                                PartnerAddress = reader.GetString(reader.GetOrdinal("address")),
                                OrderStatusId = reader.GetInt32(reader.GetOrdinal("order_status_id")),
                                OrderStatusName = reader.GetString(reader.GetOrdinal("order_status_name")),
                                OrderDate = reader.GetDateTime(reader.GetOrdinal("order_date")),
                                TotalCost = reader.GetDecimal(reader.GetOrdinal("total_cost")),
                                Comment = reader.IsDBNull(reader.GetOrdinal("comment"))
                                    ? null
                                    : reader.GetString(reader.GetOrdinal("comment"))
                            };

                            if (!reader.IsDBNull(reader.GetOrdinal("prepayment_deadline")))
                            {
                                order.PrepaymentDeadline = reader.GetDateTime(reader.GetOrdinal("prepayment_deadline"));
                            }
                            order.PrepaymentReceived = reader.GetBoolean(reader.GetOrdinal("prepayment_received"));

                            reader.Close();
                            order.Items = new ObservableCollection<OrderItem>(
                                await GetOrderItemsAsync(order.Id)
                            );
                            return order;
                        }
                    }
                }
            }

            return null;
        }
    }
}