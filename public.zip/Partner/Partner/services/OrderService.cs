﻿using PartnerOrderApp.WPF.Models;
using System.Collections.Generic;

namespace PartnerOrderApp.WPF.Services
{
    public class OrderService
    {
        public decimal CalculateTotalCost(IEnumerable<OrderItem> items)
        {
            if (items == null)
                return 0;

            decimal total = 0;
            foreach (var item in items)
            {
                total += item.Quantity * item.UnitPrice;
            }

            return System.Math.Round(total, 2);
        }

        public bool IsOrderValid(PartnerOrder order, out string errorMessage)
        {
            errorMessage = string.Empty;

            if (order == null)
            {
                errorMessage = "Заявка не может быть пустой";
                return false;
            }

            if (order.PartnerId <= 0)
            {
                errorMessage = "Необходимо выбрать партнёра";
                return false;
            }

            if (order.Items == null || order.Items.Count == 0)
            {
                errorMessage = "Заявка должна содержать хотя бы одну позицию продукции";
                return false;
            }

            foreach (var item in order.Items)
            {
                if (item.Quantity <= 0)
                {
                    errorMessage = "Количество продукции \"" + item.ProductName + "\" должно быть больше 0";
                    return false;
                }

                if (item.UnitPrice < 0)
                {
                    errorMessage = "Цена продукции \"" + item.ProductName + "\" не может быть отрицательной";
                    return false;
                }
            }

            return true;
        }
    }
}