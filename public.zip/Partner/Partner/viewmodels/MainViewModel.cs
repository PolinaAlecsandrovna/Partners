﻿using PartnerOrderApp.WPF.Models;      
using PartnerOrderApp.WPF.Services;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;

namespace PartnerOrderApp.WPF.ViewModels
{
    public class MainViewModel : ViewModelBase
    {
        private readonly DatabaseService _dbService;
        private readonly OrderService _orderService;
        private readonly DialogService _dialogService;

        private ObservableCollection<OrderCardViewModel> _orders = new();
        private bool _isLoading;
        private string _errorMessage = string.Empty;

        public ObservableCollection<OrderCardViewModel> Orders
        {
            get => _orders;
            set
            {
                _orders = value;
                OnPropertyChanged();
            }
        }

        public bool IsLoading
        {
            get => _isLoading;
            set
            {
                _isLoading = value;
                OnPropertyChanged();
            }
        }

        public string ErrorMessage
        {
            get => _errorMessage;
            set
            {
                _errorMessage = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(HasError));
            }
        }

        public bool HasError => !string.IsNullOrEmpty(ErrorMessage);

        public ICommand LoadOrdersCommand { get; }
        public ICommand AddOrderCommand { get; }
        public ICommand RefreshCommand { get; }
        public ICommand OpenOrderEditCommand { get; }

        public event System.Action AddOrderRequested;
        public event System.Action<PartnerOrder> EditOrderRequested;

        public MainViewModel(DatabaseService dbService, OrderService orderService,
            DialogService dialogService)
        {
            _dbService = dbService;
            _orderService = orderService;
            _dialogService = dialogService;

            LoadOrdersCommand = new RelayCommand(async _ => await LoadOrdersAsync());
            AddOrderCommand = new RelayCommand(_ => AddOrderRequested?.Invoke());
            RefreshCommand = new RelayCommand(async _ => await LoadOrdersAsync());
            OpenOrderEditCommand = new RelayCommand(OnOpenOrderEdit);

            LoadOrdersCommand.Execute(null);
        }

        private async Task LoadOrdersAsync()
        {
            IsLoading = true;
            ErrorMessage = string.Empty;

            try
            {
                var orders = await _dbService.GetAllOrdersAsync();
                Orders = new ObservableCollection<OrderCardViewModel>(
                    orders.Select(o => new OrderCardViewModel(o, _dbService, _orderService, _dialogService))
                );

                foreach (var card in Orders)
                {
                    card.OrderDeleted += async () => await LoadOrdersAsync();
                    card.OrderEdited += (order) => EditOrderRequested?.Invoke(order);
                }
            }
            catch (System.Exception ex)
            {
                ErrorMessage = $"Ошибка загрузки данных: {ex.Message}";
                _dialogService.ShowError(ErrorMessage);
            }
            finally
            {
                IsLoading = false;
            }
        }

        private void OnOpenOrderEdit(object parameter)
        {
            if (parameter is PartnerOrder order)
            {
                EditOrderRequested?.Invoke(order);
            }
        }

        public async Task RefreshOrdersAsync()
        {
            await LoadOrdersAsync();
        }
    }
}
