﻿using PartnerOrderApp.WPF.Models;      
using PartnerOrderApp.WPF.Services;
using System.Windows.Input;

namespace PartnerOrderApp.WPF.ViewModels
{
    public class OrderCardViewModel : ViewModelBase
    {
        private readonly DialogService _dialogService;
        private readonly DatabaseService _dbService;
        private readonly OrderService _orderService;

        public PartnerOrder Order { get; }

        public ICommand EditCommand { get; }
        public ICommand DeleteCommand { get; }

        public event System.Action OrderDeleted;
        public event System.Action<PartnerOrder> OrderEdited;

        public OrderCardViewModel(PartnerOrder order, DatabaseService dbService,
            OrderService orderService, DialogService dialogService)
        {
            Order = order;
            _dbService = dbService;
            _orderService = orderService;
            _dialogService = dialogService;

            EditCommand = new RelayCommand(_ => OnEdit());
            DeleteCommand = new RelayCommand(async _ => await OnDelete());
        }

        private void OnEdit()
        {
            OrderEdited?.Invoke(Order);
        }

        private async System.Threading.Tasks.Task OnDelete()
        {
            if (!_dialogService.ShowConfirmation(
                $"Вы действительно хотите удалить заявку №{Order.Id}?",
                "Подтверждение удаления"))
            {
                return;
            }

            try
            {
                await _dbService.DeleteOrderAsync(Order.Id);
                _dialogService.ShowMessage("Заявка успешно удалена", "Успех");
                OrderDeleted?.Invoke();
            }
            catch (System.Exception ex)
            {
                _dialogService.ShowError($"Ошибка при удалении заявки: {ex.Message}");
            }
        }
    }
}
