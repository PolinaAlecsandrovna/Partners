﻿namespace PartnerOrderApp.WPF.Models
{
    public class Partner
    {
        public int Id { get; set; }
        public int PartnerTypeId { get; set; }
        public string PartnerTypeName { get; set; }
        public string CompanyName { get; set; }
        public string Inn { get; set; }
        public string DirectorSurname { get; set; }
        public string DirectorName { get; set; }
        public string DirectorPatronymic { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public int Rating { get; set; }
        public string Address { get; set; }

        public Partner()
        {
            PartnerTypeName = string.Empty;
            CompanyName = string.Empty;
            Inn = string.Empty;
            DirectorSurname = string.Empty;
            DirectorName = string.Empty;
            DirectorPatronymic = string.Empty;
            Phone = string.Empty;
            Email = string.Empty;
            Address = string.Empty;
        }
    }
}