﻿namespace PartnerOrderApp.WPF.Models
{
    public class Product
    {
        public int Id { get; set; }
        public string Article { get; set; }
        public string Name { get; set; }
        public decimal MinPartnerPrice { get; set; }

        public Product()
        {
            Article = string.Empty;
            Name = string.Empty;
        }
    }
}