﻿using System;
using System.Collections.ObjectModel;

namespace PartnerOrderApp.WPF.Models
{
    public class PartnerOrder
    {
        public int Id { get; set; }
        public int PartnerId { get; set; }
        public string PartnerName { get; set; }
        public string PartnerTypeName { get; set; }
        public string PartnerPhone { get; set; }
        public int PartnerRating { get; set; }
        public string PartnerAddress { get; set; }
        public int OrderStatusId { get; set; }
        public string OrderStatusName { get; set; }
        public DateTime OrderDate { get; set; }
        public DateTime? PrepaymentDeadline { get; set; }
        public bool PrepaymentReceived { get; set; }
        public decimal TotalCost { get; set; }
        public string Comment { get; set; }
        public ObservableCollection<OrderItem> Items { get; set; }

        public PartnerOrder()
        {
            PartnerName = string.Empty;
            PartnerTypeName = string.Empty;
            PartnerPhone = string.Empty;
            PartnerAddress = string.Empty;
            OrderStatusName = string.Empty;
            Comment = string.Empty;
            Items = new ObservableCollection<OrderItem>();
        }
    }

    public class OrderStatus
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public OrderStatus()
        {
            Name = string.Empty;
        }
    }
}